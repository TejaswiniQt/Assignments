#include<stdio.h>
#include"pattern3.h"
int main()
{
	int num = 5;
	char ch ='A';
	pattern3(num, ch);
}
