void pattern3(int num, char ch);
