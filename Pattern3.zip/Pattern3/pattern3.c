#include<stdio.h>
#include"pattern3.h"

void pattern3(int num, char ch)
{
	for(int i = 0;i < num;i++)
	{
		for(int j = 0;j < num;j++)
		{
			if(j >= i)
			{
				printf("%c", ch);
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
		ch++;
	}
}
