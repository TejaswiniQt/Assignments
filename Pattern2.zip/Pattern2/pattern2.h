void pattern2(int num, char ch);
