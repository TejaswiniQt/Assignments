#include<stdio.h>
#include"pattern2.h"

void pattern2(int num, char ch)
{
	for(int i = 0;i < num;i++)
	{
		for(int j = 0;j < num;j++)
		{
			if(j >= i)
			{
				printf("%c", ch);
			}
			else
			{
				printf(" ");
			}
			ch++;
		}
		printf("\n");
		ch = 'A';
	}
}
