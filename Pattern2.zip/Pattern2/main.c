#include<stdio.h>
#include"pattern2.h"
int main()
{
	int num = 5;
	char ch ='A';
	pattern2(num, ch);
}
