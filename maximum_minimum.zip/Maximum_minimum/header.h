void scan_array(int *arr, int size);
int max_min(int *arr, int size);
