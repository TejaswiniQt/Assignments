#include<stdio.h>
#include"header.h"
int main()
{
	int size;
	printf("Enter array size: ");
	scanf("%d", &size);
	int arr[size];
	scan_array(arr, size);
	max_min(arr, size);
	printf("Maximum is %d\n", arr[size-1]);
	printf("Minimum is %d\n", arr[0]);
}
