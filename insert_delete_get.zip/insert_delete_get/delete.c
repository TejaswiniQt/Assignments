#include<stdio.h>
#include"delete.h"
int delete(int a[],int n)
{
    int pos,i;
    printf("Enter the position you want to delete: ");
    scanf("%d",&pos);

    if(pos<=0 || pos>n)
    printf("Invalid position\n");
    else
    {
	for(i=pos-1;i<n-1;i++)
	{
	    a[i]=a[i+1];
	}
	n--;
	printf("After deletion: ");
	for(i=0;i<n;i++)
	{
	    printf("%d ",a[i]);
	}
	printf("\n");
    }
    return 0;
}
