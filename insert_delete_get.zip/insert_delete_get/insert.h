
int insert(int a[],int n);
