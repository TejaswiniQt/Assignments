#include<stdio.h>
#include"insert.h"
int insert(int a[],int n)
{
    int num,pos,i;
    printf("Enter the data you want to insert: ");
    scanf("%d",&num);
    printf("Enter position: ");
    scanf("%d",&pos);

    if(pos <=0 || pos >n+1)
    {
	printf("Invalid position\n");
    }
    else
    {

	for(i=n-1;i>=pos-1;i--)
	{
	    a[i+1]=a[i];
	}
	a[pos-1]=num;
	n++;
	printf("After Inserting: ");
	for(i=0;i<n;i++)
	{
	    printf("%d ",a[i]);
	}
	printf("\n");
    }
    return 0;
}
