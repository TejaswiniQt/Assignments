int get(int a[],int n);
