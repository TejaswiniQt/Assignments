#include<stdio.h>
#include"insert.h"
#include"delete.h"
#include"get.h"
int main()
{
    int a[50],n,i,option;
    printf("1.Insert\n2.Delete\n3.Getdata\n");
    scanf("%d",&option);
    switch(option)
    {
	case 1:
    printf("Enter the size of array: ");
    scanf("%d",&n);
    printf("Enter the elements of the arry: ");
    for(i=0;i<n;i++)
    {
	scanf("%d",&a[i]);
    }
    insert(a,n);
    break;
	case 2:
    printf("Enter the size of array: ");
    scanf("%d",&n);
    printf("Enter the elements of the arry: ");
    for(i=0;i<n;i++)
    {
	scanf("%d",&a[i]);
    }
    delete(a,n);
    break;
	case 3:
    printf("Enter the size of array: ");
    scanf("%d",&n);
    printf("Enter the elements of the arry: ");
    for(i=0;i<n;i++)
    {
	scanf("%d",&a[i]);
    }
    get(a,n);
    break;
    }
    return 0;
}
