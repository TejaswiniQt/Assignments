#include<stdio.h>
#include"get.h"
int get(int a[],int n)
{
    int pos,i;
    printf("Enter the position to get the data: ");
    scanf("%d",&pos);
    for(i=0;i<n;i++)
    {
	if(i==pos-1)
	{
	    printf("%d\n",a[i]);
	}
    }

    return 0;
}
