#include<stdio.h>
#include"length.h"
#include"concatenate.h"
void concatenate(char des[],char src[])
{
    int len1,len2,len3,i=0;
    len1=length(des);
    len2=length(src);
    for(i=0;i<=len2;i++)
    {
       des[len1+i]=src[i];
    }
    printf("The concatenated string:  %s\n",des);
    len3=length(des);
    printf("The length of concatenated string is: %d\n",len3);
}



