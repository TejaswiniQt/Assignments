void concatenate(char des[],char src[]);
