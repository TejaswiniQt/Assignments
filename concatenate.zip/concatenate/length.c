#include<stdio.h>
#include"length.h"
int length(char *des)
{
    int count=0,i=0;
    while(des[i] != '\0')
    {
	count++;
	i++;
    }
    return count;
}
