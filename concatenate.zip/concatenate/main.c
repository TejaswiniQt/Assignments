#include<stdio.h>
#include"concatenate.h"
#include"length.h"
int main()
{
    char des[50],src[20];
    int i,len1,len2;
    printf("Enter string1: ");
    scanf("%s",des);
    printf("Enter string2: ");
    scanf("%s",src);
    concatenate(des,src);
    return 0;
}
