int length(char *des);
