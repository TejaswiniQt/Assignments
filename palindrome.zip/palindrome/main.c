#include<stdio.h>
#include<string.h>
#include"palindrome.h"
int  main()
{
    char s[1000];
    printf("Enter the string: ");
    scanf("%s",s);

    if(palindrome(s))
	printf("string is palindrome\n");
    else
	printf("string is not palindrome\n");
}

