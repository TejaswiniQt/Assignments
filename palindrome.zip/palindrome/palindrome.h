int palindrome(char *s);
