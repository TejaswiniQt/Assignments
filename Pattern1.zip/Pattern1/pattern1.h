void pattern1(int num);
