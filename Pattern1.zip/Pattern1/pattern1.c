#include<stdio.h>
#include"pattern1.h"

void pattern1(int num)
{
	for(int i = 0;i < num;i++)
	{
		for(int j = 0;j < num;j++)
		{
			if(j >= i)
			{
				printf("*");
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
	}
}
