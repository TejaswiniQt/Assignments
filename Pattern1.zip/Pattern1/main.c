#include<stdio.h>
#include"pattern1.h"
int main()
{
	int num = 5;
	pattern1(num);
}
