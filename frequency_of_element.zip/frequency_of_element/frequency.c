#include<stdio.h>
#include"frequency.h"
int frequency(int *a,int *b,int n)
{
    int i,j,c=0;
    for(i=0;i<n;i++)
    {
	c=1;
	    for(j=i+1;j<n;j++)
	    {
		if(a[i]==a[j])
		{
		    c++;
		    b[j]=0;
		}
	    }

	if(b[i]!=0)
	{
	    b[i]=c;
	}
    }
    return 0;
}
