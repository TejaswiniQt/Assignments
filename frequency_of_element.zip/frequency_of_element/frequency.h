
int frequency(int *a,int *b,int n);
