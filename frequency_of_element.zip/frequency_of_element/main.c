#include<stdio.h>
#include"frequency.h"
#include"print.h"
int main()
{
    int a[100],b[100],n,i;
    printf("Enter the size of array: ");
    scanf("%d",&n);
    printf("Enter the elements of the array: ");
    for(i=0;i<n;i++)
    {
	scanf("%d",&a[i]);
	b[i]=-1;
    }
    frequency(a,b,n);
    print(a,b,n);
    return 0;
}
