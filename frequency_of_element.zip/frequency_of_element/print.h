int print(int *a,int *b,int n);
