#include<stdio.h>
#include"print.h"
int print(int *a,int *b,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
	if(b[i]!=0)
	{
	    printf("Number of %d is %d\n",a[i],b[i]);
	}
    }
    return 0;
}
