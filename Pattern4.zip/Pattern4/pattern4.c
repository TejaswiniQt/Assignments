#include<stdio.h>
#include"pattern4.h"

void pattern4(int num, int num1)
{
	for(int i = 0;i < num;i++)
	{
		for(int j = 0;j < num;j++)
		{
			if(j >= i)
			{
				printf("%d", num1);
			}
			else
			{
				printf(" ");
			}
		}
		printf("\n");
		num1 = num1 - 2;
	}
}
