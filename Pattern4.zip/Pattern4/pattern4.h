void pattern4(int num, int num1);
