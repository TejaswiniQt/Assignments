#include<stdio.h>
#include"pattern4.h"
int main()
{
	int num = 5;
	int num1 = 9;
	pattern4(num, num1);
}
