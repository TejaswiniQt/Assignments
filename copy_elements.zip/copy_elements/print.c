#include<stdio.h>
#include"print.h"
int print(int a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
	printf("%d ",a[i]);
    }
    return 0;
}
