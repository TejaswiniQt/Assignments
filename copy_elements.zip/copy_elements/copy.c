#include<stdio.h>
#include"copy.h"
int copy(int *a,int *b,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
	b[i]=a[i];
    }
    return 0;
}
