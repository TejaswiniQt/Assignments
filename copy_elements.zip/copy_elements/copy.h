int copy(int *a,int *b,int n);
