#include<stdio.h>
#include"copy.h"
#include"print.h"
int main()
{
    int a[100],b[100],i,n;

    printf("Enter the size of arry: ");
    scanf("%d",&n);
    printf("Enter the elements of the array: ");
    for(i=0;i<n;i++)
    {
	scanf("%d",&a[i]);
    }
    copy(a,b,n);
    printf("First  array: ");
    print(a,n);
    printf("\n");
    printf("Second array: ");
    print(b,n);
    printf("\n");
    return 0;
}

