int print(int a[],int n);
