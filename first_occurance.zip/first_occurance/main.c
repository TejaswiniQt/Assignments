#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"check.h"
#define N 1000
int main()
{
    char s[N],w[N];
    printf("Enter the string: ");
    scanf("%[^\n]%*c", s);

    printf("Enter the word to be searched: ");
    scanf("%[^\n]%*c", w);

    check(s,w);

    return 0;
}
