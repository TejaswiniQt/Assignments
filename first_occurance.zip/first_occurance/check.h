int check(char *s,char *w);
